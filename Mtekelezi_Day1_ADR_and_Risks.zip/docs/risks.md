# Top Risks & Mitigations (v1)

> This log tracks technical/product risks for the week‑1 MVP. Keep entries short and actionable.

| # | Risk | Impact | Likelihood | Mitigation | Owner | Status |
|---|------|--------|------------|------------|-------|--------|
| 1 | **Invalid JSON from LLM** | Blocks DB writes & page generation | Medium | **Retry once** with `prompts/repair.txt`; strict schema validation before any side‑effects; cap output tokens | Eng | Open |
| 2 | **RLS misconfiguration** | Data leakage across users | Low‑Med | **Smoke tests**: cross‑tenant reads/writes must 403; enforce server‑side `user_id` checks; enable RLS on all tables | Eng | Open |
| 3 | **LLM quota / rate limits** | 429 errors; failed agent runs | Medium | **Cooldown + per‑user rate limit** (5/hour); exponential backoff; cache last successful plan per idea; disable re‑run <10 min | Eng | Open |

## Watchlist (add as needed)
- Public page leakage (should 404 unless `is_public=true`); sanitize markdown only.
- Secrets exposure (never commit `.env`; use Vercel env vars).
- Schedule/task mismatch (server consistency check ensures all scheduled titles exist).
